const pinoPretty = require('pino-pretty');

module.exports = function pinoPrettyTransport(opts) {
  return pinoPretty({
    ...opts,
    messageFormat(log, messageKey, levelLabel) {
      try {
        // Extract serializable fields if they exist
        const correlationId = log?.req?.headers?.['x-correlation-id'];
        const method = log?.req?.method;
        const url = log?.req?.url;
        const statusCode = log?.res?.statusCode;
        const msg = log[messageKey] || 'No message';
        const context = log.context||'HttpRequest';
        // Determine color based on log level
        let msgColor = '\x1b[32m';
        let contextColor='\x1b[36m'
        let methodColor='\x1b[33m'
        let correlationColor='\x1b[35m'
        let statusColor=' \x1b[36m'
        if (log.level >= 50) {
          methodColor=contextColor=correlationColor=msgColor=statusColor = '\x1b[31m'; 
        }

        // Construct the message conditionally
        let formattedMessage = `${msgColor}${msg}\x1b[0m`;

        if (context) {
          formattedMessage = `${contextColor}[${context}]\x1b[0m ` + formattedMessage;
        }
        if (method && url) {
          formattedMessage = `${methodColor}${method} ${url}\x1b[0m - ` + formattedMessage;
        }
        if (correlationId) {
          formattedMessage = `${correlationColor}[${correlationId}]\x1b[0m ` + formattedMessage;
        }
        if (statusCode) {
          formattedMessage += `${statusColor}(Status: ${statusCode})\x1b[0m`;
        }

        return formattedMessage;
      } catch (error) {
        return `Log processing error: ${error.message}`;
      }
    }
  });
};