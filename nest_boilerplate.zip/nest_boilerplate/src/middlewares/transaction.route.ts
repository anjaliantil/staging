import { RequestMethod } from "@nestjs/common";


export const transactionRoutes=[
    {path:'product',method:RequestMethod.ALL},
    {path:'product/:id',method:RequestMethod.ALL}
]