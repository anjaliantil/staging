import { Injectable, Logger, NestMiddleware } from '@nestjs/common';
import { DataSource } from 'typeorm';
 
@Injectable()
export class TransactionMiddleware implements NestMiddleware {
private logger=new Logger(TransactionMiddleware.name)
  constructor(private readonly dataSource: DataSource) {}
 
  async use(req: any, res: any, next: (error?: any) => void) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
 
    req.transaction = queryRunner.manager; // Attach transaction manager to request
    res.on('finish', async () => {
      try {
        if (res.statusCode >= 200 && res.statusCode < 400) {
          await queryRunner.commitTransaction();
          this.logger.log('Transaction completed')
        } else {
          await queryRunner.rollbackTransaction();
          this.logger.error('Rollbacking the transaction')
        }
      } catch (error) {
        this.logger.error(error)
        this.logger.error('Rollbacking the transaction')
        await queryRunner.rollbackTransaction();
      } finally {
        await queryRunner.release();
      }
    });
   
 
    next();
  }
}