import { BadRequestException, Controller, Get, Inject } from '@nestjs/common';
import { HealthCheck, HealthCheckService, HttpHealthIndicator, MemoryHealthIndicator, MicroserviceHealthIndicator, TypeOrmHealthIndicator } from '@nestjs/terminus';
import {
  RedisOptions,
  Transport,
} from '@nestjs/microservices';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
@Controller('health')
export class HealthController {
  constructor(
    private healthCheckService: HealthCheckService,
    private http: HttpHealthIndicator,
    private memory: MemoryHealthIndicator,
    private db: TypeOrmHealthIndicator,
    private microservice: MicroserviceHealthIndicator,
    private httpService:HttpService
  ) {}
 
  @Get()
  @HealthCheck()
  async check() {
    const results:any = [];
    const errors:any=[]
  
    try {
      
      const checks = [
        {
          name: 'nestjs-docs',
          check: async () => this.http.pingCheck('nestjs-docs', 'https://docs.nestjs.com'),
        },
        {
          name: 'memory_heap',
          check: async () => this.memory.checkHeap('memory_heap', 300 * 1024 * 1024),
        },
        {
          name: 'memory_rss',
          check: async () => this.memory.checkRSS('memory_rss', 500 * 1024 * 1024),
        },
        {
          name: 'database',
          check: async () => this.db.pingCheck('database'),
        },
        {
          name: 'redis',
          check: async () => this.microservice.pingCheck<RedisOptions>('redis', {
            transport: Transport.REDIS,
            options: {
              host: 'localhost',
              port: 6379,
            },
          })
        },
      ];
  
      for (const { name, check } of checks) {
        try {
          const result:any = await check();
         
          if(result[name].status=='up'){
            results.push({ name, status: 'up'});
          }else{
            results.push({ name, status: 'down' });
          }
         
        } catch (error:any) {
           
          errors.push({
            name,
            status: 'error',
            message: error.message,
            stack: error.stack,
          });
        }
      }
     
      return {
        message: 'Health check completed',
        data: results,
        error: errors,
      };
    } catch (error:any) {
      return {
        status: 'error',
        message: 'An unexpected error occurred during the health check process',
        data: results,
        error: {
          message: error.message,
          stack: error.stack,
        },
      };
    }
  }

  @Get('/error')
  async throw_error(){
    const response = await firstValueFrom(
      this.httpService.get('https://jsonplaceholder.typicode.com/users')
    );
    return response
  }

  
}
