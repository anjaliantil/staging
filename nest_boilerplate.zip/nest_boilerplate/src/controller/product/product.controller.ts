import { Body, Controller, Get, Logger, Param, Post, Put } from '@nestjs/common';
import { Product } from 'src/entities/product.entity';
import { ProductService } from '../../services/product.service';
import { CreateProductDTO } from 'src/dto/create-product.dto';
import { UpdateProductDTO } from 'src/dto/update-product.dto';


@Controller('product')
export class ProductController {
  private logger=new Logger(ProductController.name);
  
constructor(private productService:ProductService){}

@Post()
addProduct(@Body() product:CreateProductDTO){
  return this.productService.create(product)
}

@Put('/:id')
updateProduct(@Param('id') id:string,@Body() product:UpdateProductDTO){
  this.logger.log('Initializing the product update step')
  
  return this.productService.update(+id,product)
}
@Get()
getProduct(){
    return this.productService.findAll()
}
}
