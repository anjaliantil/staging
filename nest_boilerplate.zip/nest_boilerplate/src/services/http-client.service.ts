import { HttpService } from "@nestjs/axios";
import { Injectable, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { firstValueFrom } from "rxjs";
import config from "src/config";
import { CreateUserDTO } from "src/dto/create-user.dto";
import { User } from "src/entities/user.entity";
import { Repository } from "typeorm";


@Injectable()
export class ProductService {
     private logger=new Logger(ProductService.name);
constructor(@InjectRepository(User) private repo:Repository<User>,private httpService:HttpService){


}

async syncToDB(){
    const response = await firstValueFrom(
        this.httpService.get(config().url)
      );
      if(!response){
        
       return false
      }
      const users: CreateUserDTO[] = response.data.map((user:CreateUserDTO) => ({
        name: user.name,
        username: user.username,
        email: user.email,
        address: {
          street: user.address.street,
          suite: user.address.suite,
          city: user.address.city,
          zipcode: user.address.zipcode,
          geo: {
            lat: user.address.geo.lat,
            lng: user.address.geo.lng,
          },
        },
        phone: user.phone,
        website: user.website,
        company: {
          name: user.company.name,
          catchPhrase: user.company.catchPhrase,
          bs: user.company.bs,
        },
      }));
      this.repo.create(users)
}
}