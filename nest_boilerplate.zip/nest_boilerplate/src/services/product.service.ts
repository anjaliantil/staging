import { Inject, Injectable, InternalServerErrorException, Logger, NotFoundException, Scope } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { sleep } from '@nestjs/terminus/dist/utils';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateProductDTO } from 'src/dto/create-product.dto';
import { UpdateProductDTO } from 'src/dto/update-product.dto';
import { Product } from 'src/entities/product.entity';
import { Repository, DataSource, EntityManager } from 'typeorm';

@Injectable({scope: Scope.REQUEST })
export class ProductService {
     private logger=new Logger(ProductService.name);
constructor( @Inject(REQUEST) private readonly request: any,@InjectRepository(Product) private repo:Repository<Product>,  private readonly dataSource: DataSource,){

    
}
async create(product: CreateProductDTO): Promise<Product> {
  const transactionManager: EntityManager = this.request.transaction || this.repo.manager;
    try {
      const productEntity =transactionManager.create(Product, product);
      const savedProduct = await transactionManager.save(productEntity);
      return savedProduct;
    } catch (error) {
      throw error;
    }
  }
  async update(id: number, productData: UpdateProductDTO): Promise<Product> {
    const transactionManager: EntityManager = this.request.transaction || this.repo.manager;
   
    try {
        const product = await transactionManager.findOne(Product, { where: { productID:id } });
        if(!product){
            throw new NotFoundException(`Product with id ${id} not found`)
          }
      await transactionManager.update(Product, id, productData);
      const updatedProduct = await transactionManager.findOne(Product, { where: { productID:id } });
      if(!updatedProduct){
        throw new InternalServerErrorException(`Failed to retrieve updated product`)
      }
      return updatedProduct
      
    } catch (error) {
    
      throw error;
    }
  }




findAll(){
    return this.repo.find()
}
}

