import { Inject, Injectable, InternalServerErrorException, Logger, NotFoundException } from '@nestjs/common';
import { sleep } from '@nestjs/terminus/dist/utils';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateProductDTO } from 'src/dto/create-product.dto';
import { UpdateProductDTO } from 'src/dto/update-product.dto';
import { Product } from 'src/entities/product.entity';
import { Repository, DataSource } from 'typeorm';

@Injectable()
export class ProductService {
     private logger=new Logger(ProductService.name);
constructor(@InjectRepository(Product) private repo:Repository<Product>,  private readonly dataSource: DataSource,){

    
}
async create(product: CreateProductDTO): Promise<Product> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
   
    await queryRunner.startTransaction();
    try {
      const productEntity = queryRunner.manager.create(Product, product);
      const savedProduct = await queryRunner.manager.save(productEntity);
      await queryRunner.commitTransaction();
      return savedProduct;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  async update(id: number, productData: UpdateProductDTO): Promise<Product> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    this.logger.log('Starting transactions for update')
    await queryRunner.startTransaction();
    try {
        const product = await queryRunner.manager.findOne(Product, { where: { productID:id } });
        if(!product){
            throw new NotFoundException(`Product with id ${id} not found`)
          }
      await queryRunner.manager.update(Product, id, productData);
      const updatedProduct = await queryRunner.manager.findOne(Product, { where: { productID:id } });
      if(!updatedProduct){
        throw new InternalServerErrorException(`Failed to retrieve updated product`)
      }
     
      await queryRunner.commitTransaction();
      this.logger.log('Transaction completed')
      return updatedProduct
      
    } catch (error) {
      this.logger.error(error)
      this.logger.error('Rollbacking the transaction')
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }




findAll(){
    return this.repo.find()
}
}

