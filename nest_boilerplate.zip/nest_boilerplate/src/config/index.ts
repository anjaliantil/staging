export default () => ({
  ...process.env,
  get: function(key:string) : any {
    let config:Record<string, any> = {...this};
    return config[key];
  },
   url:'https://jsonplaceholder.typicode.com/users'
});
