import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProductModule } from './controller/product/product.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { LoggerModule } from 'nestjs-pino';
import { Product } from './entities/product.entity';
import { HealthModule } from './controller/healthCheck/health.module';
import { v4 as uuidv4 } from 'uuid';
import { ResponseInterceptor } from './interceptors/response.interceptor';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { ErrorInterceptor } from './interceptors/error.interceptor';
import config from './config';
@Module({
  imports: [ProductModule, HealthModule,
    
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: `.env`,
    }),
    LoggerModule.forRoot({
      pinoHttp: {
        name: 'NEST',
        level: process.env.LOG_LEVEL || 'info',
        genReqId: (req: any) => {
          return req.headers['x-correlation-id'] || uuidv4();
        },
        redact: ['request.headers.authorization'],
        transport: {
          target:require.resolve('../pino-transport') , // Pretty logs for development
          options: {
            colorize: true,
            singleLine: true,
            levelFirst: false,
            translateTime: "yyyy-MM-dd'T'HH:mm:ss.l'Z'",
            ignore: "pid,hostname,context,req,res,responseTime,err",
            errorLikeObjectKeys: ['err', 'error'],


        },

        },



      }
    }),
    ConfigModule.forRoot({
      envFilePath: '.env',
    }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: config().get('POSTGRES_HOST'),
      port:  config().get('POSTGRES_PORT'),
      username:  config().get('POSTGRES_USER'),
      password:  config().get('POSTGRES_PASSWORD'),
      database:  config().get('POSTGRES_DB'),
      entities: [Product], // Add your entities here
      synchronize: true, // Set to false in production
    }),
    
  ],
  controllers: [AppController],
  providers: [AppService,
    {
      provide:APP_INTERCEPTOR,
      useClass:ResponseInterceptor
    },
    {
      provide:APP_INTERCEPTOR,
    useClass:ErrorInterceptor    }
  ],
})
export class AppModule {}
