import { Module, ValidationPipe, MiddlewareConsumer } from '@nestjs/common';
import { APP_INTERCEPTOR, APP_PIPE } from '@nestjs/core';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './controllers/users/users.module';
import { ReportsModule } from './controllers/reports/reports.module';
import { User } from './controllers/users/user.entity';
import { Report } from './controllers/reports/report.entity';
import { ThrottlerModule } from '@nestjs/throttler';
import { CacheModule } from '@nestjs/cache-manager';
import { LoggerService } from './services/logger/logger.service';
import { LoggerMiddleware } from './middlewares/logger.middleware';
import { ErrorInterceptor } from './interceptors/error.interceptor';
import { ResponseInterceptor } from './interceptors/response.interceptor';
const cookieSession = require('cookie-session');

@Module({
  imports: [
    //for rate limiting
    ThrottlerModule.forRoot([{
      ttl: 60000,
      limit: 10,
    }]),

    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: `.env`,
    }),
    
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        return {
          type: 'sqlite',
          database: config.get<string>('DB_NAME'),
          synchronize: true,
          entities: [User, Report],
        };
      },
    }),
    // TypeOrmModule.forRoot({
    //   type: 'sqlite',
    //   database: 'db.sqlite',
    //   entities: [User, Report],
    //   synchronize: true,
    // }),
    UsersModule,
    ReportsModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,LoggerService,

    {
      provide:APP_INTERCEPTOR,
      useClass:ErrorInterceptor
    },
    {
      provide:APP_INTERCEPTOR,
      useClass:ResponseInterceptor
    },
    
   
  ],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(
        cookieSession({
          keys: ['asdfasfd'],
        })
      )
      .forRoutes('*');
  }
}
