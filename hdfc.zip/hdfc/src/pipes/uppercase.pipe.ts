import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';
 
@Injectable()
export class UppercasePipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata) {
    if (typeof value === 'string') {
      return value.toUpperCase(); // Convert string to uppercase
    } else if (typeof value === 'object' && value !== null) {
      return this.convertObjectToUppercase(value); // Convert all object values to uppercase
    }
    return value; // Return unchanged if not a string or object
  }
 
  private convertObjectToUppercase(obj: any): any {
    return Object.keys(obj).reduce((acc, key) => {
      acc[key] =
        typeof obj[key] === 'string' ? obj[key].toUpperCase() : obj[key];
      return acc;
    }, {});
  }
}
