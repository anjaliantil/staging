import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable, catchError, throwError } from 'rxjs';
import { Request } from 'express';
import { HttpException, InternalServerErrorException } from '@nestjs/common';
import { LoggerService } from 'src/services/logger/logger.service';
 
@Injectable()
export class ErrorInterceptor implements NestInterceptor {
  constructor(private loggerService:LoggerService){}
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    return next.handle().pipe(
      catchError((error) => {
        const request = context.switchToHttp().getRequest<Request>();
 
        // Extract user details (if available)
        const user = request?.currentUser || { id: 'unknown', email: 'unknown' };
 
        // Build error log structure
        const errorLog = {
          timestamp: new Date().toISOString(),
          path: request.url,
          method: request.method,
          headers: request.headers,
          user: {
id: user.id,
email: user.email,
          },
          error: {
name: error.name || 'UnknownError',
            message: error.message || 'An unexpected error occurred',
            stack: error.stack || 'No stack trace available',
            statusCode: error.status || 500,
          },
        };
 
        // Log error (can be stored in DB or external service)
        this.loggerService.logError(errorLog,'ERROR DETECTED', )
 
        // If it's an HTTP exception, rethrow it; otherwise, wrap it in a generic error
        if (error instanceof HttpException) {
          return throwError(() => error);
        } else {
          return throwError(() => new InternalServerErrorException(errorLog));
        }
      }),
    );
  }
}