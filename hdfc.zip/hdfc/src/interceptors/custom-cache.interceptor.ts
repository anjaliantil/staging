import { Cache, CACHE_MANAGER, CacheInterceptor } from '@nestjs/cache-manager';
import { Injectable, ExecutionContext, CallHandler, NestInterceptor, Inject } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LoggerService } from 'src/services/logger/logger.service';

@Injectable()
export class CustomCacheInterceptor extends CacheInterceptor {
  constructor(@Inject(CACHE_MANAGER)cacheManager:Cache,reflector:Reflector,private readonly logger:LoggerService){
    super(cacheManager,reflector)
  }
  async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
    const isCached = await this.isCached(context);
    if (isCached) {
      this.logger.logProcess('Response is coming from cache')
      context.switchToHttp().getResponse().setHeader('X-Cache-Status', 'HIT');
    } else {
      this.logger.logProcess('Response is coming from database')
      context.switchToHttp().getResponse().setHeader('X-Cache-Status', 'MISS');
    }

    return next.handle().pipe(
      tap(async (response) => {
        if (!isCached) {
          const cacheKey = this.trackBy(context);
          if (cacheKey) {
         const data= await this.cacheManager.set(cacheKey, response);
            this.logger.logProcess('Storing response in cache')
          }
        }
      }),
    );
  }

  private async isCached(context: ExecutionContext): Promise<boolean> {
    
    const cacheKey = this.trackBy(context);
    
    if (!cacheKey) {
      return false;
    }
    console.log(cacheKey)
    const value = await this.cacheManager.get(cacheKey);

    
    return !!value;
  }
}