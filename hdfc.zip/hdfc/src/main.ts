import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import helmet from 'helmet';
import { Logger } from '@nestjs/common';
import { LoggerService } from './services/logger/logger.service';
import { CustomExceptionFilter } from './filters/custom-exception.filter';
async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger=app.get(LoggerService)
  app.useLogger(logger)
  app.useGlobalFilters(new CustomExceptionFilter(logger))
  app.enableCors();
  (app as any).set('etag', false);//This line disables the ETag header.
                                                   
app.use(helmet());                        
  app.use((req, res, next) => {
    res.removeHeader('x-powered-by');
    res.removeHeader('date');
    next();
  });
  await app.listen(3000);
}
bootstrap();
