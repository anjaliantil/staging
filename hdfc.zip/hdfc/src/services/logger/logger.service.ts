import { ConsoleLogger, Injectable, Scope } from '@nestjs/common';
 
@Injectable({ scope: Scope.DEFAULT })  // New logger instance for each injection
export class LoggerService extends ConsoleLogger {
 
  logRequest(method: string, url: string, body: any, userId?: string|number) {
    const userInfo = userId ? `UserID: ${userId}` : 'Guest User';
    this.log(`[API HIT] ${method} ${url} | ${userInfo} | Body: ${JSON.stringify(body)}`);
  }
 
  logProcess(message: string, meta?: any) {
    this.log(`[PROCESS] ${message} ${meta ? '| Meta: ' + JSON.stringify(meta) : ''}`);
  }
 
  logError(error: any, context: string) {
    this.error(`[ERROR] Context: ${context} | Error: ${JSON.stringify(error)}`);
  }
}