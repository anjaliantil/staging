import {
  Injectable,
  BadRequestException,
  NotFoundException,
  Inject,
} from '@nestjs/common';
import { randomBytes, scrypt as _scrypt } from 'crypto';
import { promisify } from 'util';
import { JwtService } from '@nestjs/jwt';
import { LoggerService } from 'src/services/logger/logger.service';
import { UsersService } from '../users/users.service';

const scrypt = promisify(_scrypt);

@Injectable()
export class AuthService {
  constructor(private usersService: UsersService, private jwtService: JwtService,private readonly logger:LoggerService) {}

  async signup(email: string, password: string) {
    // See if email is in use
    this.logger.logProcess('Starting singup process',{email:email})

    try{
    const users = await this.usersService.find(email);
    if (users.length) {
      throw new BadRequestException('email in use');
    }

    // Hash the users password
    // Generate a salt
    const salt = randomBytes(8).toString('hex');

    // Hash the salt and the password together
    const hash = (await scrypt(password, salt, 32)) as Buffer;

    // Join the hashed result and the salt together
    const result = salt + '.' + hash.toString('hex');
     
    // Create a new user and save it
    const user = await this.usersService.create(email, result);
    this.logger.logProcess('Signup successful',{userId:user.id})
    // return the user
    return user;
  }catch(error){
    this.logger.logError(error,'Signup Process')
    throw error
  }
  }

  async signin(email: string, password: string) {
    const [user] = await this.usersService.find(email);
    if (!user) {
      this.asyncError()
      throw new NotFoundException('user not found');
    }

    const [salt, storedHash] = user.password.split('.');

    const hash = (await scrypt(password, salt, 32)) as Buffer;

    if (storedHash !== hash.toString('hex')) {
      throw new BadRequestException('bad password');
    }

    const payload = { sub: user.id, email: user.email };
    user['access_token']=await this.jwtService.signAsync(payload)
    return user
  }

  async asyncError(){
    return new Promise((_,reject)=>{
      setTimeout(()=>reject(new Error('Unhandled Promise Rejection!')),1000)
    })
  }
}
