import { Module, MiddlewareConsumer } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersController } from './users.controller';
import { User } from './user.entity';
import { CurrentUserMiddleware } from '../../middlewares/current-user.middleware';
import { JwtModule } from '@nestjs/jwt';
import { ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { LoggerService } from 'src/services/logger/logger.service';
import { LoggerMiddleware } from 'src/middlewares/logger.middleware';
import { UsersService } from 'src/services/users/users.service';
import { AuthService } from 'src/services/auth/auth.service';
import { ErrorInterceptor } from 'src/interceptors/error.interceptor';
import { ProcessErrorMiddleware } from 'src/middlewares/process-error.middleware';

@Module({
  imports: [TypeOrmModule.forFeature([User]),
  UsersModule,
  JwtModule.register({
    global: true,
    secret: "sjjkdjfkfjk",
    signOptions: { expiresIn: '60s' },
  }),],
  controllers: [UsersController],
  providers: [UsersService, AuthService,{
    provide: APP_GUARD,
    useClass: ThrottlerGuard
  }
  
  ,LoggerService],
})
export class UsersModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(ProcessErrorMiddleware,CurrentUserMiddleware,LoggerMiddleware).forRoutes('*');
  }
}
