import {
  Body,
  Controller,
  Post,
  Get,
  Patch,
  Delete,
  Param,
  Query,
  NotFoundException,
  Session,
  UseGuards,
  Res,
  StreamableFile,
  Header,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { CreateUserDto } from '../../dtos/create-user.dto';
import { UpdateUserDto } from '../../dtos/update-user.dto';
import { Serialize } from '../../interceptors/serialize.interceptor';
import { UserDto } from '../../dtos/user.dto';
import { CurrentUser } from '../../decorators/current-user.decorator';
import { User } from './user.entity';
import { AuthGuard } from '../../guards/auth.guard';
import { createReadStream, readFileSync } from 'fs';
import { join } from 'path';
import { UsersService } from 'src/services/users/users.service';
import { AuthService } from 'src/services/auth/auth.service';
import { UppercasePipe } from 'src/pipes/uppercase.pipe';

@Controller('auth')
@Serialize(UserDto)
export class UsersController {
  constructor(
    private usersService: UsersService,
    private authService: AuthService,
  ) {}

  @Get('/whoami')
  @UseGuards(AuthGuard)
  whoAmI(@CurrentUser() user: User) {
    return user;
  }

  @Post('/signout')
  signOut(@Session() session: any) {
    session.userId = null;
  }

  @Post('/signup')
  async createUser(@Body(UppercasePipe) body: CreateUserDto, @Session() session: any) {
    const user = await this.authService.signup(body.email, body.password);
    session.userId = user.id;
    return user;
  }

  @Post('/signin')
  async signin(@Body() body: CreateUserDto, @Session() session: any) {
    const user = await this.authService.signin(body.email, body.password);
    session.userId = user.id;
    return user;
  }

  @Get('/:id')
  async findUser(@Param('id') id: string) {
    const user = await this.usersService.findOne(parseInt(id));
    if (!user) {
      throw new NotFoundException('user not found');
    }
    return user;
  }

  @Get()
  findAllUsers(@Query('email') email: string) {
    return this.usersService.find(email);
  }

  @Delete('/:id')
  removeUser(@Param('id') id: string) {
    return this.usersService.remove(parseInt(id));
  }

  @Patch('/:id')
  updateUser(@Param('id') id: string, @Body() body: UpdateUserDto) {
    return this.usersService.update(parseInt(id), body);
  }

//this will download file
  @Get('/read/file')
  @Header('Content-Type', 'application/json')
  @Header('Content-Disposition', 'attachment; filename="package.json"')
  getFileUsingStaticValues(): StreamableFile {
    const file = createReadStream(join(process.cwd(), 'package.json'));
    console.log(file)
    return new StreamableFile(file);
  } 

  //read file

  @Get('/read/file-content')
  @Header('Content-Type', 'application/json')
  getFileDataUsingStaticValues(): any {
    const filePath = join(process.cwd(), 'package.json');
    const fileContent = readFileSync(filePath, 'utf-8');
    console.log(fileContent)
    return fileContent;
  }


  @Get('http-error')
  throwHttpError(){
    throw new HttpException('Bad Request Error',HttpStatus.BAD_REQUEST)
  }
}
