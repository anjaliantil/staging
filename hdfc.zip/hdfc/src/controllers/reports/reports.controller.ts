import {
  Controller,
  Post,
  Body,
  UseGuards,
  Patch,
  Param,
  UseInterceptors,
  Get,
} from '@nestjs/common';
import { CreateReportDto } from '../../dtos/create-report.dto';
import { AuthGuard } from '../../guards/auth.guard';
import { CurrentUser } from '../../decorators/current-user.decorator';
import { User } from '../users/user.entity';
import { Serialize } from '../../interceptors/serialize.interceptor';
import { ApproveReportDto } from '../../dtos/approve-report.dto';
import { AdminGuard } from '../../guards/admin.guard';
import { ReportDto } from 'src/dtos/report.dto';
import { ReportsService } from 'src/services/reports/reports.service';


@Controller('reports')
@UseGuards(AuthGuard)
export class ReportsController {
  constructor(private reportsService: ReportsService) {}

  @Post()
  @Serialize(ReportDto)
  createReport(@Body() body: CreateReportDto, @CurrentUser() user: User) {
    return this.reportsService.create(body, user);
  }

  @Patch('/:id')
  @UseGuards(AdminGuard)
  approveReport(@Param('id') id: string, @Body() body: ApproveReportDto) {
    return this.reportsService.changeApproval(id, body.approved);
  }

  @Get()
  getAllReport(){
    return this.reportsService.find()
  }
}
