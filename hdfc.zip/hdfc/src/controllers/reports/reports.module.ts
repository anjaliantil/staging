import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReportsController } from './reports.controller';
import { Report } from './report.entity';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ThrottlerGuard } from '@nestjs/throttler';
import { CacheInterceptor, CacheModule } from '@nestjs/cache-manager';
import { CustomCacheInterceptor } from 'src/interceptors/custom-cache.interceptor';
import { LoggerService } from 'src/services/logger/logger.service';
import { ReportsService } from 'src/services/reports/reports.service';

@Module({
  imports: [TypeOrmModule.forFeature([Report]),
  CacheModule.register(),],
  controllers: [ReportsController],
  providers: [ReportsService,
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard
    },
    {
      provide:APP_INTERCEPTOR,
      useClass:CustomCacheInterceptor
    },LoggerService
  ],
})
export class ReportsModule {}
