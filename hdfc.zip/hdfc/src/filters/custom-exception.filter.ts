import {
    ExceptionFilter,
    Catch,
    ArgumentsHost,
    HttpException,
    HttpStatus,
  } from '@nestjs/common';
  import { Request, Response } from 'express';
import { LoggerService } from 'src/services/logger/logger.service';
   
  @Catch() // This catches ALL exceptions
  export class CustomExceptionFilter implements ExceptionFilter {
    constructor(private loggerService:LoggerService){}
    catch(exception: unknown, host: ArgumentsHost) {
      const ctx = host.switchToHttp();
      const response = ctx.getResponse<Response>();
      const request = ctx.getRequest<Request>();
   
      // Check if exception is an HttpException
      const status =
        exception instanceof HttpException
          ? exception.getStatus()
          : HttpStatus.INTERNAL_SERVER_ERROR;
   
      const message =
        exception instanceof HttpException
          ? exception.getResponse()
          : 'Internal server error';
   
      const errorResponse = {
        statusCode: status,
        message: message,
        timestamp: new Date().toISOString(),
        path: request.url,
      };
      this.loggerService.logError(errorResponse,'Exception caught')
      response.status(status).json(errorResponse);
    }
  }