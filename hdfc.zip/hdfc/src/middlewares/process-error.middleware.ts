import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { LoggerService } from 'src/services/logger/logger.service';
 
@Injectable()
export class ProcessErrorMiddleware implements NestMiddleware {
  constructor(private loggerService:LoggerService) {
    this.handleProcessErrors();
  }
 
  private handleProcessErrors() {
    // Catch Uncaught Exceptions (Sync Errors)
    process.on('uncaughtException', (error) => {
      console.error('🛑 Uncaught Exception:', error);
      this.logError('UncaughtException', error);
    });
 
    // Catch Unhandled Promise Rejections (Async Errors)
    process.on('unhandledRejection', (reason, promise) => {
      console.error('🛑 Unhandled Rejection at:', promise, 'Reason:', reason);
      this.logError('UnhandledRejection', reason);
    });
  }
 
  private logError(type: string, error: any) {
    const errorDetails = {
      type,
      timestamp: new Date().toISOString(),
      message: error?.message || 'Unknown error',
      stack: error?.stack || 'No stack trace available',
    };
 
    this.loggerService.logError(errorDetails,' Process-Level Error');
 
  }
 
  use(req: Request, res: Response, next: NextFunction) {
    next(); 
  }
}