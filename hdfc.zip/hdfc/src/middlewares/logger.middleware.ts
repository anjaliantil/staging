import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { LoggerService } from 'src/services/logger/logger.service';
import { User } from 'src/controllers/users/user.entity';
 
declare global {
  namespace Express {
    interface Request {
      currentUser?: User;
    }
  }
}
@Injectable()
export class LoggerMiddleware implements NestMiddleware {
  constructor(private readonly logger: LoggerService) {}
 
  use(req: Request, res: Response, next: NextFunction) {
    const { method, originalUrl, currentUser } = req;
const userId = req.currentUser ? req.currentUser.id : 'Guest';  // Assuming you attach user info after auth
  const body =req.currentUser?{email:currentUser?.email,id:currentUser.id}:{user:'Guest'}
    this.logger.logRequest(method, originalUrl, body, userId);
    
    res.on('finish', () => {
      this.logger.log(`[RESPONSE] ${method} ${originalUrl} | Status: ${res.statusCode}`);
    });
 
    next();
  }
}