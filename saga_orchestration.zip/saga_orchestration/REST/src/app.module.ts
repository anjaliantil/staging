import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProductModule } from './controller/product/product.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { LoggerModule } from 'nestjs-pino';
import { Product } from './entities/product.entity';
import { HealthModule } from './controller/product/healthCheck/health.module';
import { v4 as uuidv4 } from 'uuid';
import { ResponseInterceptor } from './interceptors/response.interceptor';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { ErrorInterceptor } from './interceptors/error.interceptor';
@Module({
  imports: [ProductModule, HealthModule,
    
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: `.env`,
    }),
    LoggerModule.forRoot({
      pinoHttp: {
        name: 'REST Client',
        level: process.env.LOG_LEVEL || 'info',
        genReqId: (req: any) => {
          return req.headers['x-correlation-id'] || uuidv4();
        },
        redact: ['request.headers.authorization'],
        transport: {
          target:require.resolve('../pino-transport') , // Pretty logs for development
          options: {
            colorize: true,
            singleLine: true,
            levelFirst: false,
            translateTime: "yyyy-MM-dd'T'HH:mm:ss.l'Z'",
            ignore: "pid,hostname,context,req,res,responseTime,err",
            errorLikeObjectKeys: ['err', 'error'],


        },

        },



      }
    }),
    ConfigModule.forRoot({
      envFilePath: '.env',
    }),
    // TypeOrmModule.forRoot({
    //   type: 'postgres',
    //   host: JSON.stringify(process.env.POSTGRES_HOST),
    //   port: parseInt(JSON.stringify(process.env.POSTGRES_PORT)),
    //   username: JSON.stringify(process.env.POSTGRES_USER),
    //   password: JSON.stringify(process.env.POSTGRES_PASSWORD),
    //   database: JSON.stringify(process.env.POSTGRES_DB),
    //   entities: [Product], // Add your entities here
    //   synchronize: true, // Set to false in production
    // }),
    TypeOrmModule.forRoot({
      // type:'sqlite',
      // database:'db.sqlite',
      // entities:[User,Report],
      // synchronize:true
      type: 'postgres',
        host: 'localhost',
        port: 5433,
        username: 'postgres',
        password: 'admin@123',
        database: 'app',
        autoLoadEntities: true,
        synchronize: true, // not recommended for production
    })
  ],
  controllers: [AppController],
  providers: [AppService,
    {
      provide:APP_INTERCEPTOR,
      useClass:ResponseInterceptor
    },
    {
      provide:APP_INTERCEPTOR,
    useClass:ErrorInterceptor    }
  ],
})
export class AppModule {}
