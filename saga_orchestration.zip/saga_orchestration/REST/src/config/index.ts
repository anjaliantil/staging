export default () => ({
  ...process.env,
  get: function(key:string) : any {
    let config:Record<string, any> = {...this};
    console.log(key)
    return config[key];
  },
});
