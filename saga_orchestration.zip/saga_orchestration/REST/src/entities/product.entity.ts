import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('products')
export class Product {
  @PrimaryGeneratedColumn()
  productID: number;

  @Column({ type: 'varchar', length: 255 })
  productName: string;

  @Column({ type: 'varchar', length: 255 })
  category: string;

  @Column({ type: 'decimal' })
  price: number;

  @Column({ type: 'int' })
  stockQuantity: number;

  @Column({ type: 'float' })
  rating: number;
}