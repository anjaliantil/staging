import { Inject } from '@nestjs/common';
import { PaymentServiceInterface } from './payment.service.interface';
import { PaymentRepositoryInterface } from 'src/repositories/payment.repository.interface';
import { Payment } from 'src/entities/payment';
import { CustomLoggerService } from './custom-logger.service';
 // Import custom logger service

export class PaymentService implements PaymentServiceInterface {
  constructor(
    @Inject('payment-repository')
    private paymentRepository: PaymentRepositoryInterface,
    private readonly logger: CustomLoggerService, // Inject custom logger
  ) {}

  authorizePayment(request: { orderId: string; amount: number }): { authorized: boolean } {
   this.logger.log(`Starting payment authorization for Order ID: ${request.orderId}, Amount: ${request.amount}`, 'PaymentService'); // Log payment authorization

    // Simulate calling a third-party payment provider
    const payment = new Payment({ ...request });
    payment.authroize();
    
    this.paymentRepository.save(payment);
   this.logger.log(`Payment authorized for Order ID: ${request.orderId}.`, 'PaymentService'); // Log successful authorization

    return { authorized: true };
  }

  refund(request: { orderId: string; amount: number }): void {
   this.logger.log(`Initiating refund for Order ID: ${request.orderId}, Amount: ${request.amount}`, 'PaymentService'); // Log refund initiation

    const payment = this.paymentRepository.findByOrderId(request.orderId);
    if (!payment) {
      this.logger.warn(`No payment found for Order ID: ${request.orderId}. Refund failed.`, 'PaymentService'); // Log if payment not found
      return;
    }

    payment.cancel();
    this.paymentRepository.update(payment);

   this.logger.log(`Refund successful for Order ID: ${request.orderId}.`, 'PaymentService'); // Log successful refund
  }
}
