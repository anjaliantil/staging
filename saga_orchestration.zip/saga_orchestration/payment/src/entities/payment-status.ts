export const enum PaymentStatus {
  AUTHORIZED,
  CANCELED,
}
