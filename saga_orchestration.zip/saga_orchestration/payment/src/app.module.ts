import { Module } from '@nestjs/common';

import { ConfigModule } from '@nestjs/config';
import config from './config';
import { AuthorizePaymentController } from './usecases/authorize-payment/authorize-payment.controller';
import { PaymentRepository } from './repositories/memory/payment.repository';
import { PaymentService } from './services/payment.service';
import { LoggerModule } from 'nestjs-pino';
import { CustomLoggerService } from './services/custom-logger.service';

@Module({
  imports: [
    LoggerModule.forRoot({
      pinoHttp: {
        serializers: {
          req(req) {
            return {
              method: req.method,
              url: req.url,
              // Remove headers and full body details
            };
          },
        },
        transport: {
          target: 'pino-pretty', // Pretty logs for development
          options: {
            colorize: true,
            translateTime: 'HH:MM:ss Z',
            ignore: 'pid,hostname', // Removes unwanted fields
          },
        },
      },
    }),
    ConfigModule.forRoot({ isGlobal: true, load: [config] })],
  controllers: [AuthorizePaymentController],
  providers: [
    {
      provide: 'payment-repository',
      useClass: PaymentRepository,
    },
    {
      provide: 'payment-service',
      useClass: PaymentService,
    },CustomLoggerService
  ],
})
export class AppModule {}
