import { Module } from '@nestjs/common';
import config from './config';
import { ConfigModule } from '@nestjs/config';
import { ProductRepository } from './repositories/memory/product.repository';
import { CheckProductAvailibityController } from './usecases/fetch-availible-products/check-products-availiblity.controller';
import { UpdateStockController } from './usecases/update-stock/update-stock.controller';
import { ProductService } from './services/product.service';
import { LoggerModule } from 'nestjs-pino';
import { CustomLoggerService } from './services/custom-logger.service';

@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true, load: [config] }),
  LoggerModule.forRoot({
    pinoHttp: {
      serializers: {
        req(req) {
          return {
            method: req.method,
            url: req.url,
            // Remove headers and full body details
          };
        },
      },
      transport: {
        target: 'pino-pretty', // Pretty logs for development
        options: {
          colorize: true,
          translateTime: 'HH:MM:ss Z',
          ignore: 'pid,hostname', // Removes unwanted fields
        },
      },
    },
  }),
],
  controllers: [CheckProductAvailibityController, UpdateStockController],
  providers: [
    {
      provide: 'product-repository',
      useClass: ProductRepository,
    },
    {
      provide: 'product-service',
      useClass: ProductService,
    },
    CustomLoggerService
  ],
})
export class AppModule {}
