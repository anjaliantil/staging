import { Inject, Injectable } from '@nestjs/common';
import { ProductServiceInterface } from './product.service.interface';
import { ProductRepositoryInterface } from 'src/repositories/product.repository.interface';
import { Product } from 'src/entities/product';
import { CustomLoggerService } from './custom-logger.service';
; // Import the custom logger service

@Injectable()
export class ProductService implements ProductServiceInterface {
  constructor(
    @Inject('product-repository')
    private productRepository: ProductRepositoryInterface,
    private readonly logger: CustomLoggerService, // Inject the custom logger
  ) {}

  checkProductAvailibity(request: { [id: string]: number }): boolean {
    this.logger.log(`Checking product availability for request: ${JSON.stringify(request)}`, 'ProductService'); // Log the request

    const products = this.productRepository.findMany(Object.keys(request));

    const areAllProductsAvailable = products.every((product) =>
      product.isStockSufficient(request[product.id]),
    );

    this.logger.log(`Product availability check completed for request: ${JSON.stringify(request)}. Result: ${areAllProductsAvailable}`, 'ProductService'); // Log the result
    return areAllProductsAvailable;
  }

  reduceStockQuantity(request: { [id: string]: number }): void {
    this.logger.log(`Reducing stock quantity for products: ${JSON.stringify(request)}`, 'ProductService'); // Log the request

    const products = this.productRepository.findMany(Object.keys(request));

    products.forEach(
      (product, index, arr) => {
        arr[index].quantity -= request[product.id];
      },
    );

    this.productRepository.updateMany(products);

    this.logger.log(`Stock quantity reduced for request: ${JSON.stringify(request)}. Updated products: ${JSON.stringify(products)}`, 'ProductService'); // Log the updated products
  }

  restockQuantity(request: { [id: string]: number }): void {
    this.logger.log(`Restocking products: ${JSON.stringify(request)}`, 'ProductService'); // Log the request

    const products = this.productRepository.findMany(Object.keys(request));

    products.forEach(
      (product, index, arr) => {
        arr[index].quantity += request[product.id];
      },
    );

    this.productRepository.updateMany(products);

    this.logger.log(`Products restocked for request: ${JSON.stringify(request)}. Updated products: ${JSON.stringify(products)}`, 'ProductService'); // Log the updated products
  }
}
