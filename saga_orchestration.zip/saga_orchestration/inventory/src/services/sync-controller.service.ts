import { Inject, Injectable } from '@nestjs/common';
import { ProductServiceInterface } from './product.service.interface';
import { ProductRepositoryInterface } from 'src/repositories/product.repository.interface';
import { Product } from 'src/entities/product';
import { CustomLoggerService } from './custom-logger.service';
import { firstValueFrom } from 'rxjs';
import { HttpService } from '@nestjs/axios';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from 'src/entities/user.entity';
import { Repository } from 'typeorm';
import { CreateUserDTO } from 'src/dto/create-user.dto';
import config from 'src/config';
; // Import the custom logger service

@Injectable()
export class SyncControllerService {
  constructor(
    @InjectRepository(User) private repo:Repository<User>,
    private readonly logger: CustomLoggerService, private httpService:HttpService
  ) {}

 

  async checkProductSync(data:any){
    this.logger.log(`Initializing controller Sync: ${JSON.stringify(data)}`, 'SyncControllerService');
    const response = await firstValueFrom(
      this.httpService.get(config().url)
    );
    console.log(response)
    if(!response){
      
     return false
    }
    const users: CreateUserDTO[] = response.data.map((user:CreateUserDTO) => ({
      name: user.name,
      username: user.username,
      email: user.email,
      address: {
        street: user.address.street,
        suite: user.address.suite,
        city: user.address.city,
        zipcode: user.address.zipcode,
        geo: {
          lat: user.address.geo.lat,
          lng: user.address.geo.lng,
        },
      },
      phone: user.phone,
      website: user.website,
      company: {
        name: user.company.name,
        catchPhrase: user.company.catchPhrase,
        bs: user.company.bs,
      },
    }));
    this.repo.create(users)
    return true

  }
}
