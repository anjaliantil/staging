import { MessagePattern, Payload } from '@nestjs/microservices';
import { Controller, Inject } from '@nestjs/common';
import { ProductServiceInterface } from 'src/services/product.service.interface';
import { SyncControllerService } from 'src/services/sync-controller.service';

type CheckProductsAvailibilityMessage = {
  products: [
    {
      id: string;
      quantity: number;
    },
  ];
};

type CreateUserDTO= {
    name: string;
    username: string;
    email: string;
    address: object;
    phone: string;
    website: string;
    company: object;
  }

@Controller()
export class SyncController {
  constructor(
    @Inject('sync-service')
    private readonly service: SyncControllerService,
  ) {}

  @MessagePattern('sync.controller.get')
  checkSync(@Payload() message: CreateUserDTO) {

    return this.service.checkProductSync(message)
   
    };
  
}
