import { Inject, Injectable, Logger } from '@nestjs/common';
import { Step } from './step';
import { OrderRepositoryInterface } from 'src/repositories/order.repository.interface';
import { Order } from 'src/entities/order';
;

@Injectable()
export class PlaceOrderStep extends Step<Order, void> {
  private logger:Logger=new Logger(PlaceOrderStep.name)
  constructor(
    @Inject('order-repository')
    private orderRepository: OrderRepositoryInterface,
  ) {
    super();
    this.name = 'Place Order Step';
  }

  invoke(order: Order): Promise<void> {
    
    this.orderRepository.save(order);
    this.logger.log('Order Placed')
    return Promise.resolve();
  }

  withCompenstation(order: Order): Promise<void> {
    order.cancel();
    this.orderRepository.update(order);
    return Promise.resolve();
  }
}
