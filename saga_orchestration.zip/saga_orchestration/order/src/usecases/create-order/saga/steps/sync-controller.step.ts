import { Inject, Injectable, Logger } from '@nestjs/common';
import { Step } from './step';
import { OrderRepositoryInterface } from 'src/repositories/order.repository.interface';
import { Order } from 'src/entities/order';
import {ClientProxy, ClientProxyFactory} from '@nestjs/microservices';
import config from 'src/config';
import { lastValueFrom } from 'rxjs';
import { OutOfStockError } from 'src/exceptions/out_of_stock_error';

@Injectable()
export class syncControllerStep extends Step<Order, void> {
   private logger:Logger=new Logger(syncControllerStep.name)
   constructor(
      @Inject(config().services.inventory.name)
      private inventoryClient: ClientProxy,
    ) {
      
      super();
      this.name = 'Sync Controller step';
    }
  
    async invoke(order: Order): Promise<void> {
      this.logger.log('Syncing controller with inventory')
      const isSynced = await lastValueFrom(
        this.inventoryClient.send('sync.controller.get', {
          products: order.orderItems.map((item) => ({
            id: item.productId,
            quantity: item.quantity,
          })),
        }),
      );
   
      if (!isSynced) {
        throw new OutOfStockError(
          `${order.orderItems.map((item) => item.productId)} is not availbe`,
        );
      }
      this.logger.log('Sync completed')
    }
  
    withCompenstation(params: Order): Promise<any> {
      return Promise.resolve();
    }
  
}
