import { IsString, IsNumber, IsNotEmpty } from 'class-validator';


export class CreateOrderDto {
  @IsString()
  customerId: string;

  @IsNotEmpty()
  orderItems: CreateOrderItemDto[];
}

export class CreateOrderItemDto {
  @IsString()
  productId: string;

  @IsNumber()
  quantity: number;

  @IsNumber()
  totalPrice: number;
}
