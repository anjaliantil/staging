export default () => ({
  broker: process.env.BROKER ?? 'localhost:6379', // Default Redis broker address
  services: {
    order: {
      name: 'order-redis-client', // Renamed to reflect Redis usage
    },
    payment: {
      name: 'payment-redis-client', // Renamed to reflect Redis usage
    },
    inventory: {
      name: 'inventory-redis-client', // Renamed to reflect Redis usage
    },
  },
});
