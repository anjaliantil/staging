export default () => ({
  ...process.env,
  broker: process.env.BROKER ?? 'localhost:6379', // Default Redis broker address
  services: {
    order: {
      name: 'order-redis-client', // Renamed to reflect Redis usage
    },
    payment: {
      name: 'payment-redis-client', // Renamed to reflect Redis usage
    },
    inventory: {
      name: 'inventory-redis-client', // Renamed to reflect Redis usage
    },
  },
PORT:3000,
  get: function(key:string) : any {
    let config:Record<string, any> = {...this};
    console.log(key)
    return config[key];
  },
});
