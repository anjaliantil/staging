import { BaseError } from './base_error';

export class OutOfStockError extends BaseError {}
