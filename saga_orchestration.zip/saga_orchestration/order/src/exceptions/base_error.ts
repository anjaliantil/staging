export class BaseError extends Error {}
