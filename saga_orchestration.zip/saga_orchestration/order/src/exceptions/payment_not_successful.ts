import { BaseError } from './base_error';

export class PaymentNotSuccessfulError extends BaseError {}
