import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { ConfigModule } from '@nestjs/config';
import { Logger } from 'nestjs-pino';
import { v4 as uuidv4 } from 'uuid';
import { CorrelationIdMiddleware } from './middlewares/correlation-id.middleware';
import config from './config';

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Application specific logging, throwing an error, or other logic here
});
console.log(config().get('PORT'))
async function bootstrap() {
  const app = await NestFactory.create(AppModule,  {bufferLogs: true});
  app.useGlobalPipes(new ValidationPipe({ whitelist: true }));
 
  app.use(new CorrelationIdMiddleware().use)
  app.useLogger(app.get(Logger));

  
  await app.listen(3001);
  // const microservice = await NestFactory.createMicroservice<MicroserviceOptions>(AppModule, {
  //   transport: Transport.REDIS,
  //   options: { host:'localhost', port: 6379 },
  // });

  const microservice = await NestFactory.createMicroservice<MicroserviceOptions>(AppModule, {
    transport: Transport.RMQ,
    options: {
      urls: ['amqp://localhost:5672'],
      queue: 'order_queue',
      queueOptions: {
        durable: false,
      },
    },
  });

  await microservice.listen();
 
}

bootstrap();
