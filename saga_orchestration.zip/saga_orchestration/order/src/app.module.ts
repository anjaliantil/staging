import { OrderRepository } from './repositories/memory/order.repository';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import config from './config';
import { CreateOrderController } from './usecases/create-order/create-order.controller';
import { OrderService } from './services/order.service';
import { CreateOrderSaga } from './usecases/create-order/saga/create-order.saga';
import { PlaceOrderStep } from './usecases/create-order/saga/steps/place-order.step';
import { CheckProductsAvailibityStep } from './usecases/create-order/saga/steps/check-product-availibilty.step';
import { AuthorizePaymentStep } from './usecases/create-order/saga/steps/authorize-payment.step';
import { ConfirmOrderStep } from './usecases/create-order/saga/steps/confirm-order.step';
import { UpdateStockStep } from './usecases/create-order/saga/steps/update-stock.step';
import { CorrelationIdMiddleware } from './middlewares/correlation-id.middleware';
import { LoggerModule } from 'nestjs-pino';
import { syncControllerStep } from './usecases/create-order/saga/steps/sync-controller.step';
import { v4 as uuidv4 } from 'uuid';
import {join} from 'path'
import { HealthModule } from './healthCheck/health.module';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { ResponseInterceptor } from './interceptors/response.interceptor';
import { ErrorInterceptor } from './interceptors/error.interceptor';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: `.env`,
    }),
    LoggerModule.forRoot({
      pinoHttp: {
        name: 'Saga-Orchestrator',
        level: process.env.LOG_LEVEL || 'info',
        genReqId: (req: any) => {
          return req.headers['x-correlation-id'] || uuidv4();
        },
        redact: ['request.headers.authorization'],
        transport: {
          target:require.resolve('../pino-transport') , // Pretty logs for development
          options: {
            colorize: true,
            singleLine: true,
            levelFirst: false,
            translateTime: "yyyy-MM-dd'T'HH:mm:ss.l'Z'",
            ignore: "pid,hostname,context,req,res,responseTime,err",
            errorLikeObjectKeys: ['err', 'error'],


        },

        },



      }
    }),


    ClientsModule.register([
      {
        name: config().services.inventory.name,
        transport: Transport.RMQ,  // Change transport to RabbitMQ
        options: {
          urls: ['amqp://localhost:5672'],  // Use the broker URL for RabbitMQ
          queue: 'inventory_queue',  // Specify the queue name for the inventory service
          queueOptions: {
            durable: false,  // Set queue options as needed
          },
        },
      },
      {
        name: config().services.payment.name,
        transport: Transport.RMQ,  // Change transport to RabbitMQ
        options: {
          urls: ['amqp://localhost:5672'],  // Use the broker URL for RabbitMQ
          queue: 'payment_queue',  // Specify the queue name for the payment service
          queueOptions: {
            durable: false,  // Set queue options as needed
          },
        },
      },
    ]),HealthModule

  ],
  controllers: [CreateOrderController],
  providers: [
    {
      provide: 'order-repository',
      useClass: OrderRepository,
    },
    {
      provide: 'place-order-step',
      useClass: PlaceOrderStep,
    },
    {
      provide: 'check-products-availibity',
      useClass: CheckProductsAvailibityStep,
    },
    {
      provide: 'authorize-payment',
      useClass: AuthorizePaymentStep,
    },
    {
      provide: 'confirm-order',
      useClass: ConfirmOrderStep,
    },
    {
      provide: 'update-stock',
      useClass: UpdateStockStep,
    },
    {
      provide: 'create-order-saga',
      useClass: CreateOrderSaga,
    },
    {
      provide: 'order-service',
      useClass: OrderService,
    },
    {
      provide: 'sync-controller',
      useClass: syncControllerStep,
    },
    {
      provide:APP_INTERCEPTOR,
      useClass:ResponseInterceptor
    },
    {
      provide:APP_INTERCEPTOR,
    useClass:ErrorInterceptor    }


  ],
  exports: [],
})
export class AppModule implements NestModule{
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(CorrelationIdMiddleware).forRoutes('*')
  }
}
