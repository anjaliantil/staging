import { Injectable } from '@nestjs/common';
import { HealthIndicator, HealthIndicatorResult, HealthCheckError } from '@nestjs/terminus';
import { createClient } from 'redis';
 
@Injectable()
export class RedisHealthIndicator extends HealthIndicator {
  private client = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
 
  async isHealthy(key: string): Promise<HealthIndicatorResult> {
    try {
      await this.client.connect();
const pong = await this.client.ping();
      await this.client.disconnect();
 
      const result = this.getStatus(key, pong === 'PONG');
      return result;
    } catch (error) {
      throw new HealthCheckError('Redis check failed', this.getStatus(key, false));
    }
  }
}