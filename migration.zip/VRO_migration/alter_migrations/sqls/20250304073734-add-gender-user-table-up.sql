
ALTER TABLE users ADD COLUMN gender INT;
