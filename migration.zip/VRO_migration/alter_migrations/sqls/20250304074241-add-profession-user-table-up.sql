
ALTER TABLE users ADD COLUMN profession INT;
