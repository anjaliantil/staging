CREATE TABLE IF NOT EXISTS users(id SERIAL  PRIMARY KEY,
name VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL );

INSERT INTO public.users(
	 name, email)
	VALUES ( 'anjali', 'anjaliantil.antil@gmail.com');