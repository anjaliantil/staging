import { Module } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { OrdersController } from './orders.controller';
import { OrdersService } from './orders.service';

@Module({
  //client for rabbitMq TRANSPORT
    imports:[
        ClientsModule.register([
        {
          name: 'ORDERS_SERVICE',//token
          transport: Transport.RMQ,
          options: {
            urls: ['amqp://localhost:5672'],
            queue: 'orders_queue', //queue name
            queueOptions: {
              durable: false,
            },
          },
        },
                    ]),
   
],
controllers:[OrdersController],
providers:[OrdersService]
})
export class OrdersModule {}
