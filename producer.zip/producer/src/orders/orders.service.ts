import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
 
@Injectable()
export class OrdersService {
  
  constructor(@Inject('ORDERS_SERVICE') private rabbitClient:ClientProxy) {
  
  }
 placeOrder(order:any){
  this.rabbitClient.emit('order-placed',order)
  return {message:'Order Placed'}
 }

//   private async initialize() {
//     this.connection = await amqp.connect(this.amqpUrl);
// this.channel = await this.connection.createChannel();
// await this.channel.assertQueue(this.queue, { durable: true });
// this.consumeMessages();
//   }
 
//   // Add a message to the queue
//   async addMessageJob(data: any) {
// await this.channel.sendToQueue(this.queue, Buffer.from(JSON.stringify(data)), {
//       persistent: true,
//     });
//     console.log('Message added to the queue:', data);
//   }
 
//   // List all messages in the queue
//   async listQueueMessages() {
//     const messages:any = [];
//     let message;
 
//     do {
//        message = await this.channel.get(this.queue, { noAck: true });
//             if (message) {
//                 messages.push({
//                 content: message.content.toString(),
//                 fields: message.fields,
//         properties: message.properties,
//                 });
//             }
//             } while (message);
 
//     return messages;
//   }
//   private async consumeMessages() {
//     await this.channel.consume(this.queue, (message) => {
//       if (message !== null) {
//         console.log('Received message:', message.content.toString());
//         // Process the message here
//         this.channel.ack(message);
//       }
//     });
//   }
}