import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('fund_manager_latest')
export class FundManagerLatest extends CommonEntity {
  
  @PrimaryColumn({ type: 'bigint' })
  person_id:number 

  @Column({ type: 'date' })
  date_from:Date

  @Column({ type: 'varchar',length:100 })
  person_type:string

 

 
}