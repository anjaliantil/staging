import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';
import { TimestampEntity } from './timestamp.entity';

@Entity('indices')
export class Indices extends TimestampEntity {
  

  @PrimaryColumn({type:'bigint'})
  index_id:number

  @Column({ type: 'varchar',length:128 })
  short_name:string

  @Column({ type: 'varchar',length:256 })
  full_name:string

  
 
}