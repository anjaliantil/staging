import { Entity, Column } from 'typeorm';
import { TimestampEntity } from './timestamp.entity';

@Entity('hdfc_smartwealth_87schememaster')
export class HdfcSmarthWealth87SchemeMaster extends TimestampEntity {
  
  @Column({ type: 'varchar', length: 1 })
  function_code: string;

  @Column({ type: 'varchar', length: 20 })
  amc_code: string;

  @Column({ type: 'varchar',length:140 })
  amc_name: string;

  @Column({ type: 'varchar',length:100 })
  product_code: string;

  @Column({ type: 'varchar',length:200 })
  scheme_code: string;

  @Column({ type: 'varchar',length:300 })
  scheme_name: string;

  @Column({ type: 'varchar',length:10 })
  scheme_short_name: string;

  @Column({ type: 'varchar',length:400 })
  scheme_group: string;

  @Column({ type: 'numeric', precision: 18, scale: 2})
  unit_face_value: number;

  @Column({ type: 'varchar',length:400 })
  fund_category_description: string;

  @Column({ type: 'varchar',length:35 })
  fund_sub_category_description: string;

  @Column({ type: 'varchar',length:1 })
  scheme_option: string;

  @Column({ type: 'varchar',length:50 })
  dividend_option_flag: string;

  @Column({ type: 'varchar',length:1 })
  fund_class: string;

  @Column({ type: 'date' })
  maturity_date: Date;

  @Column({ type: 'date' })
  nfo_start_date: Date;

  @Column({ type: 'date' })
  nfo_end_date: Date;

  @Column({ type: 'numeric', precision: 19, scale: 0})
  minimum_nfo_purchase_amount: number;

  @Column({ type: 'int' })
  nfo_multiple_amount: number;

  @Column({ type: 'bigint' })
  max_nfo_amount: number;

  @Column({ type: 'date' })
  purchase_start_date: Date;

  @Column({ type: 'date' })
  purchase_end_date: Date;

  @Column({ type: 'bigint' })
  minimum_initial_purchase_amount: number;

  @Column({ type: 'bigint' })
  initial_multiple_amount: number;

  @Column({ type: 'bigint' })
  max_purchase_amount: number;

  @Column({ type: 'bigint' })
  additional_purchase_amount: number;

  @Column({ type: 'date' })
  re_purchase_start_date: Date;

  @Column({ type: 'date' })
  re_purchase_end_date: Date;


  @Column({ type: 'date' })
  redemption_start_date: Date;

  @Column({ type: 'date' })
  redemption_end_date: Date;


  @Column({ type: 'bigint' })
  minimum_redemption_amount: number;

  @Column({ type: 'bigint' })
  redemption_multiple_amount: number;

  @Column({ type: 'bigint' })
  max_redemption_amount: number;
  
  @Column({ type: 'numeric', precision: 24, scale: 4})
  min_redemption_units: number;

  @Column({ type: 'bigint'})
  max_redemption_units: number;

  @Column({ type: 'numeric', precision: 24, scale: 4})
  redemption_multiple_units: number;

  @Column({ type: 'date' })
  switch_start_date: Date;

  @Column({ type: 'date' })
  switch_end_date: Date;

  
  @Column({ type: 'bigint' })
  min_switch_amount: number;
 
  @Column({ type: 'int' })
  switch_multiple_amount: number;

  @Column({ type: 'bigint' })
  max_switch_amount: number;
  
  @Column({ type: 'numeric', precision: 24, scale: 4})
  min_switch_units: number;


  @Column({ type: 'bigint'})
  max_switch_units: number;

  @Column({ type: 'int'})
  lock_in_period: number;

  @Column({ type: 'varchar', length: 1 })
  lock_in_denoted_as: string;

  @Column({ type: 'varchar', length: 40 })
  cut_off_time_nfo: string;

  @Column({ type: 'varchar', length: 40 })
  cut_off_time_purchase: string;

  @Column({ type: 'varchar', length: 40 })
  cut_off_time_redemptions: string;

  @Column({ type: 'varchar', length: 40 })
  cut_off_time_switch: string;

  
  @Column({ type: 'varchar', length: 40 })
  cut_off_time_sip: string;

  
  @Column({ type: 'varchar', length: 40 })
  cut_off_time_stp: string;
  
  @Column({ type: 'varchar', length: 40 })
  cut_off_time_swp: string;

  
  @Column({ type: 'varchar', length: 1 })
  is_purchase_suspended: string;

  @Column({ type: 'date' })
  purchase_suspend_start_date: Date;

  @Column({ type: 'date' })
  purchase_suspend_end_date: Date;

  @Column({ type: 'varchar', length: 1 })
  purchase_suspend_lumpsum: string;

  @Column({ type: 'varchar', length: 1 })
  purchase_suspend_si_setup: string;

  @Column({ type: 'varchar', length: 1 })
  purchase_suspend_si_processing: string;

  @Column({ type: 'varchar', length: 1 })
  is_redeem_suspended: string;
 
  @Column({ type: 'date' })
  redemption_suspend_start_date: Date;

  @Column({ type: 'date' })
  redemption_suspend_lumpsum: Date;

  @Column({ type: 'varchar', length: 1 })
  redemption_suspend_si_setup: string;

  @Column({ type: 'varchar', length: 1 })
  redemption_suspend_si_processing: string;

  @Column({ type: 'varchar', length: 1 })
  is_switch_suspended: string;

  @Column({ type: 'date' })
  switch_suspend_start_date: Date;

  @Column({ type: 'date' })
  switch_suspend_end_date: Date;

  @Column({ type: 'varchar', length: 1 })
  switch_suspend_lumpsum: string;

  @Column({ type: 'varchar', length: 1 })
  switch_suspend_si_setup: string;

  @Column({ type: 'varchar', length: 1 })
  switch_suspend_si_processing: string;


  @Column({ type: 'varchar', length: 100 })
  amfi_code: string;

  @Column({ type: 'varchar', length: 20 })
  scheme_objective: string;

  @Column({ type: 'varchar', length: 1 })
  scheme_status: string;

  @Column({ type: 'varchar', length: 1 }) //not sure for this
  scheme_benchmark: string;

  @Column({ type: 'varchar', length: 100 })
  isin_code: string;

  @Column({ type: 'varchar', length: 100 })
  risk_profile: string;

  @Column({ type: 'varchar', length: 1 })
  minor_flag: string;

  @Column({ type: 'varchar', length: 300 })
  instrument_web_details1: string;

  @Column({ type: 'varchar', length: 100 })
  instrument_web_details2: string;

  @Column({ type: 'varchar', length: 1 })
  saturday_allowed_flag: string;

  @Column({ type: 'varchar', length: 10 })
  tax_category_eq_debt: string;

  @Column({ type: 'varchar', length: 1 })
  dynamic_func_y_n: string;

  @Column({ type: 'date' })
  wef_date_for_dynamic_fund: Date;

  @Column({ type: 'varchar', length: 1 })
  segregated_scheme: string;

  @Column({ type: 'varchar', length: 1 })
  fund_type: string;

  @Column({ type: 'varchar', length: 1 })
  holding_mode: string;
  





  
  
  
  



}


