import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Geo {
  @Column()
  lat: string;

  @Column()
  lng: string;
}

@Entity()
export class Company {
  @Column()
  name: string;

  @Column()
  catchPhrase: string;

  @Column()
  bs: string;
}
@Entity()
export class Address {
  @Column()
  street: string;

  @Column()
  suite: string;

  @Column()
  city: string;

  @Column()
  zipcode: string;

  @Column(type => Geo)
  geo: Geo;
}
@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  username: string;

  @Column()
  email: string;

  @Column(type => Address)
  address: Address;

  @Column()
  phone: string;

  @Column()
  website: string;

  @Column(type => Company)
  company: Company;
}



