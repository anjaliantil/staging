import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('fund_expense')
export class FundExpense extends CommonEntity {
  
  @PrimaryColumn({ type: 'date' })
  as_on_date:Date

  @Column({ type: 'numeric', precision:24,scale:8 })
  expense_ratio: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  turnover_ratio: number;

  @PrimaryColumn({ type: 'varchar',length:50 })
  frequency:string

 

 
}