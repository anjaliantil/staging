
import {Column } from 'typeorm';
import { TimestampEntity } from './timestamp.entity';

export abstract class StatsEntity extends TimestampEntity {

 
   @Column({ type: 'numeric', precision:24,scale:17 })
   standard_deviation: number;
 
   @Column({ type: 'numeric', precision:24,scale:17 })
   mean: number;
 
   @Column({ type: 'numeric', precision:24,scale:17 })
   sharpe_ratio: number;
 
   @Column({ type: 'numeric', precision:24,scale:17 })
   rsquared: number;
 
   @Column({ type: 'numeric', precision:24,scale:17 })
   beta: number;
 
   @Column({ type: 'numeric', precision:24,scale:17 })
   alpha: number;
 
   @Column({ type: 'numeric', precision:24,scale:17 })
   information_ratio: number;
 
   @Column({ type: 'numeric', precision:24,scale:17 })
   sortino_ratio: number;
}