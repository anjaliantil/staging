import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('sip_investment_details')
export class SipInvestmentDetails extends CommonEntity {
  

  @Column({ type: 'varchar',length:100 })
  plan_name:string

  //sip_frequency
  //sip_dates
  //sip_installments
  //sip_amount_from
  //sip_amount_to
  //sip_max_inv_amount
  //sip_in_multiples_of
  //minimum_agg_amount

 
}