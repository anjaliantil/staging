import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('fund_return_latest')
export class FundReturnLatest extends CommonEntity {

  @PrimaryColumn({ type: 'date' })
  return_date:Date

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_ytd: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_1day: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_1week: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_1month: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_3month: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_6month: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_9month: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_1year: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_2year: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_3year: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_4year: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_5year: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_10year: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_sinch_launch: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_7year: number;
  


 
 
}