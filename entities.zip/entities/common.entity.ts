
import {PrimaryColumn } from 'typeorm';
import { TimestampEntity } from './timestamp.entity';

export abstract class CommonEntity extends TimestampEntity {

  @PrimaryColumn({ type: 'bigint' })
  plan_id:number
}