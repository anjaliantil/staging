import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';
import { StatsEntity } from './stats.entity';

@Entity('stats_variables')
export class StatsVariables extends StatsEntity {
 
  @PrimaryColumn({ type: 'bigint' })
  plan_id:number
  
  @PrimaryColumn({ type: 'date' })
  as_on_date:Date
 
  @Column({ type: 'date' })
  rating_date:Date

  @Column({ type: 'numeric', precision:24,scale:17 })
  alpha_stated: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  beta_stated: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  rsquare_stated: number;


 

 
}