import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('fund_stylebox')
export class FundStyleBox extends CommonEntity {
  
  @PrimaryColumn({ type: 'date' })
  scrip_date:Date

  @Column({ type: 'varchar',length:200 })
  rank:string

  @Column({ type: 'varchar',length:200 })
  scrip_style:string; 

  @Column({ type: 'numeric', precision:24,scale:8 })
  pescore: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  pbscore: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  giant_percantge: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  large_percantge: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  mid_percantge: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  small_percantge: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  tiny_percantge: number;




   


  

 

 
}