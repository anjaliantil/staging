import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';
import { TimestampEntity } from './timestamp.entity';

@Entity('market_cap_monthly')
export class MarketCapMonthly extends TimestampEntity {
  

  @PrimaryColumn({type:'bigint'})
  company_id:number

  @PrimaryColumn({type:'date'})
  as_on_date:Date
  
  @Column({ type:'numeric',precision:24,scale:8})
  market_cap:string

  
 
}