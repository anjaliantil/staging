import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('schemes_sebicategory')
export class SchemesSebiCategory extends CommonEntity {
  @Column({ type: 'varchar', length: 10 })
  sebi_category_id: string;

  
 
}