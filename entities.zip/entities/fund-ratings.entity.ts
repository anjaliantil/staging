import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('fund_ratings')
export class FundRatings extends CommonEntity {
  
  @Column({ type: 'varchar', length: 200 })
  short_name: string;

  @Column({ type: 'varchar', length: 100 })
  asset_class: string;

  @Column({ type: 'varchar', length: 255 })
  category: string;
 
  @Column({ type: 'date' })
  rating_date: Date;

  @Column({ type: 'varchar', length: 30 })
  fund_rating: string;

  @Column({ type: 'varchar', length: 30 })
  previous_rating: string;

  @Column({ type: 'int' })
  change: number;

  @Column({ type: 'varchar', length: 13 })
  risk_grade: string;

  @Column({ type: 'varchar', length: 13 })
  return_grade: string;

  @Column({ type: 'varchar', length: 100 })
  code: string;

  @Column({ type: 'varchar', length: 100 })
  rta_code: string;

 
}