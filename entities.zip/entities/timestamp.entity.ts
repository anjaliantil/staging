
import { Column } from 'typeorm';

export abstract class TimestampEntity {
  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  modified_ts: Date;
}