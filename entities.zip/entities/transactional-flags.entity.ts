import { Entity, Column, PrimaryGeneratedColumn, PrimaryColumn } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('transactional_flags')
export class TransactionalFlags extends CommonEntity {

  @PrimaryColumn({ type: 'varchar',length:150 })
  subplan_id:number

  @Column({ type: 'varchar', length: 3 })
  scm_pur_available: string;

  @Column({ type: 'varchar', length: 3 })
  scm_red_available: string;

  @Column({ type: 'varchar', length: 3 })
  scm_sip_available: string;

  @Column({ type: 'varchar', length: 3 })
  scm_switch_in_available: string;
 
  @Column({ type: 'varchar', length: 3 })
  scm_switch_out_available: string;
  
  @Column({ type: 'varchar', length: 3 })
  scm_swp_available: string;

  @Column({ type: 'varchar', length: 3 })
  scm_stp_available: string;


}