import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('schemes_rollingreturns')
export class SchemesRollingReturns extends CommonEntity {
  
  @Column({ type: 'date' })
  return_date:Date

  @Column({ type: 'int' })
  obj_code:number

  @Column({ type: 'int' })
  type_code:number

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_7_days: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_14_days: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_21_days: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_28_days: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_90_days: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_180_days: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_365_days: number;

  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_730_days: number;

  
  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_1095_days: number;

  
  @Column({ type: 'numeric', precision:24,scale:17 })
  ret_1825_days: number;

  
  @Column({ type: 'int'})
  rank_7_days: number;

  @Column({ type: 'int'})
  rank_14_days: number;

  @Column({ type: 'int'})
  rank_21_days: number;

  @Column({ type: 'int'})
  rank_28_days: number;

  @Column({ type: 'int'})
  rank_90_days: number;

  @Column({ type: 'int'})
  rank_180_days: number;

  @Column({ type: 'int'})
  rank_365_days: number;

  @Column({ type: 'int'})
  rank_730_days: number;

  @Column({ type: 'int'})
  rank_1095_days: number;

  @Column({ type: 'int'})
  rank_1825_days: number;




 

 
}