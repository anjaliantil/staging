import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('fund_dividends')
export class FundDividends extends CommonEntity {
  
  @PrimaryColumn({ type: 'date' })
  div_date:Date

  @Column({ type: 'date' })
  record_date:Date

  @Column({ type: 'numeric', precision:24,scale:17 })
  percentage: number;

  @PrimaryColumn({ type: 'boolean' })
  is_tax_adjustable:boolean

  @Column({ type: 'numeric', precision:38,scale:11 })
  percentage_rs_per_unit: number;


 

 
}