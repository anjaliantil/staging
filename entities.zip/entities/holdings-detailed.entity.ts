import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { TimestampEntity } from './timestamp.entity';
import { CommonEntity } from './common.entity';

@Entity('holdings_detailed')
export class FundManagerLatest extends CommonEntity {
  
  @PrimaryColumn({ type: 'bigint' })
  company_id:number
  
  @PrimaryColumn({ type: 'bigint' })
  asset_id:number 

  @PrimaryColumn({ type: 'date' })
  asset_date:Date

  @Column({ type: 'numeric', precision:24,scale:8 })
  asset_value: number;

  @Column({ type: 'bigint' })
  num_of_shares: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  asset_percentage: number;

  @PrimaryColumn({ type: 'numeric', precision:24,scale:8 })
  coupon_rate:number
       
  @PrimaryColumn({ type: 'varchar',length:100 })
  maturity:number 

  @PrimaryColumn({ type: 'bigint' })
  rating_id: number;

  @PrimaryColumn({ type: 'varchar',length:15 })
  isin:number 

  @PrimaryColumn({ type: 'varchar',length:200 })
  rating_raw:number 
 

 
}