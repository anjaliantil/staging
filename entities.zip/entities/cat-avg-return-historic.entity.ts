import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { StatsEntity } from './stats.entity';
import { TimestampEntity } from './timestamp.entity';

@Entity('cat_avg_return_historic')
export class CatAvgReturnHistoric extends TimestampEntity {
  

  @PrimaryColumn({ type: 'int' })
  category_id:number


  @PrimaryColumn({ type: 'date' })
  return_date:Date

  @PrimaryColumn({ type: 'bigint' })
  type_id:number

  @PrimaryColumn({ type: 'varchar',length:250 })
  performanceshareclass:string

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_1day:number

  @Column({ type: 'bigint' })
  count_1day:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_1week:number

  @Column({ type: 'bigint' })
  count_1week:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_1month:number

  @Column({ type: 'bigint' })
  count_1month:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_3month:number

  @Column({ type: 'bigint' })
  count_3month:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_6month:number

  @Column({ type: 'bigint' })
  count_6month:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_9month:number

  @Column({ type: 'bigint' })
  count_9month:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_1yr:number

  @Column({ type: 'bigint' })
  count_1year:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_2yr:number

  @Column({ type: 'bigint' })
  count_2year:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_3yr:number

  @Column({ type: 'bigint' })
  count_3year:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_4yr:number

  @Column({ type: 'bigint' })
  count_4year:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_5yr:number

  @Column({ type: 'bigint' })
  count_5year:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_10yr:number

  @Column({ type: 'bigint' })
  count_10year:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_since_launch:number

  @Column({ type: 'bigint' })
  count_since_launch:number

  @Column({ type: 'numeric',precision:24,scale:17 })
  ret_ytd:number

  @Column({ type: 'bigint' })
  count_ytd:number
 
}