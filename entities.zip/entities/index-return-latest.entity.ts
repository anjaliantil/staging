import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { TimestampEntity } from './timestamp.entity';
import { CommonEntity } from './common.entity';

@Entity('index_return_latest')
export class IndexReturnLatest extends TimestampEntity {
  
  @PrimaryColumn({ type: 'bigint' })
  index_id:number
  
  @PrimaryColumn({ type: 'date' })
  return_date:Date

  @Column({ type: 'numeric', precision:24,scale:17})
  rytd: number;
 
  @Column({ type: 'numeric', precision:24,scale:17})
  r1day: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r1week: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r1month: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r3month: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r6month: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r9month: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r1year: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r2year: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r3year: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r4year: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r5year: number;

  @Column({ type: 'numeric', precision:24,scale:17})
  r10year: number;

 

 
}