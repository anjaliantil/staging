import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';

@Entity('fund_holdings_maturity_latest')
export class FundHoldingsMaturityLatest extends CommonEntity {
  
  @PrimaryColumn({ type: 'date' })
  as_on_date:Date

  @Column({ type: 'date' })
  record_date:Date

  @Column({ type: 'numeric', precision:24,scale:8 })
  average_maturity_period: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  avg_ytm: number;

  @Column({ type: 'numeric', precision:24,scale:8 })
  duration: number;



 

 
}