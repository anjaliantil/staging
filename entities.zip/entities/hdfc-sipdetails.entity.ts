import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { CommonEntity } from './common.entity';
import { TimestampEntity } from './timestamp.entity';

@Entity('hdfc_sipdetails')
export class HdfcSipDetails extends TimestampEntity {
  
  @PrimaryColumn({ type: 'varchar',length:50 })
  subplancode:string 

  @Column({ type: 'varchar',length:1 })
  function_code:string

  @Column({ type: 'varchar',length:50 })
  product_code:string

  @Column({ type: 'varchar',length:1 })
  is_sip_available:string

  @Column({ type: 'varchar',length:1 })
  sip_monthly:string

  @Column({ type: 'varchar',length:1 })
  sip_quarterly:string

  @Column({ type: 'varchar',length:1 })
  sip_daily:string

  @Column({ type: 'varchar',length:1 })
  sip_fortnightly:string

  @Column({ type: 'varchar',length:1 })
  sip_half_yearly:string

  @Column({ type: 'varchar',length:1 })
  sip_yearly:string

  @Column({ type: 'varchar',length:1 })
  sip_weekly:string

  //sip_starting_dates_monthly
  //sip_starting_dates_quarterly
  //sip_starting_dates_daily
  //sip_starting_dates_fortnightly
  //sip_starting_dates_half_yearly
  //sip_starting_dates_yearly
  //sip_starting_dates_weekly
  //sip_starting_days_weekly
  
  @Column({ type: 'int' })
  sip_min_amount:number

  @Column({ type: 'bigint' })
  sip_min_amount_monthly:number

  @Column({ type: 'bigint' })
  sip_min_amount_quarterly:number

  @Column({ type: 'bigint' })
  sip_min_amount_daily:number

  @Column({ type: 'bigint' })
  sip_min_amount_fortnightly:number

  @Column({ type: 'bigint' })
  sip_min_amount_half_yearly:number

  @Column({ type: 'bigint' })
  sip_min_amount_yearly:number

  @Column({ type: 'bigint' })
  sip_min_amount_weekly:number

  @Column({ type: 'bigint' })
  sip_maximum_amount:number

  @Column({ type: 'int' })
  sip_multiple_amount:number

  @Column({ type: 'int' })
  sip_min_installments_monthly:number

  @Column({ type: 'int' })
  sip_min_installments_quarterly:number

  @Column({ type: 'int' })
  sip_min_installments_daily:number

  @Column({ type: 'int' })
  sip_min_installments_fortnightly:number

  @Column({ type: 'int' })
  sip_min_installments_half_yearly:number

  @Column({ type: 'int' })
  sip_min_installments_yearly:number

  @Column({ type: 'int' })
  sip_min_installments_weekly:number

  @Column({ type: 'varchar',length:1 })
  is_swp_available:string

  @Column({ type: 'varchar',length:1 })
  swp_monthly:string

  @Column({ type: 'varchar',length:1 })
  swp_quarterly:string

  @Column({ type: 'varchar',length:1 })
  swp_daily:string

  @Column({ type: 'varchar',length:1 })
  swp_fortnightly:string

  @Column({ type: 'varchar',length:1 })
  swp_half_yearly:string

  @Column({ type: 'varchar',length:1 })
  swp_yearly:string

  @Column({ type: 'varchar',length:1 })
  swp_weekly:string

  @Column({ type: 'int' })
  swp_min_amount:number

  @Column({ type: 'int' })
  swp_min_amount_monthly:number

  @Column({ type: 'int' })
  swp_min_amount_quarterly:number

  @Column({ type: 'int' })
  swp_min_amount_daily:number

  @Column({ type: 'int' })
  swp_min_amount_fortnightly:number

  @Column({ type: 'int' })
  swp_min_amount_half_yearly:number

  @Column({ type: 'int' })
  swp_min_amount_yearly:number

  @Column({ type: 'int' })
  swp_min_amount_weekly:number

  @Column({ type: 'int' })
  swp_maximum_amount:number

  @Column({ type: 'int' })
  swp_multiple_amount:number

  @Column({ type: 'int' })
  swp_minimum_units:number

  @Column({ type: 'int' })
  swp_min_units_monthly:number

  @Column({ type: 'int' })
  swp_min_units_quarterly:number

  
  @Column({ type: 'int' })
  swp_min_units_daily:number

  
  @Column({ type: 'int' })
  swp_min_units_fortnightly:number

  
  @Column({ type: 'int' })
  swp_min_units_half_yearly:number

  
  @Column({ type: 'int' })
  swp_min_units_weekly:number

  
  @Column({ type: 'int' })
  swp_maximum_units:number

  
  @Column({ type: 'int' })
  swp_multiple_units:number

  //swp_starting_dates_monthly
  //swp_starting_dates_quarterly
  //swp_starting_dates_daily
  //swp_starting_dates_fortnightly
  //swp_starting_dates_half_yearly
  //swp_starting_dates_yearly
  //swp_starting_dates_weekly
  //swp_starting_days_weekly

  @Column({ type: 'int' })
  swp_min_installments_monthly:number

  @Column({ type: 'int' })
  swp_min_installments_quarterly:number

  @Column({ type: 'int' })
  swp_min_installments_daily:number

  @Column({ type: 'int' })
  swp_min_installments_fortnightly:number

  @Column({ type: 'int' })
  swp_min_installments_half_yearly:number

  @Column({ type: 'int' })
  swp_min_installments_yearly:number
  
  @Column({ type: 'int' })
  swp_min_installments_weekly:number

  @Column({ type: 'varchar',length:1 })
  is_stp_available:string

  @Column({ type: 'varchar',length:1 })
  stp_monthly:string

  @Column({ type: 'varchar',length:1 })
  stp_quarterly:string

  @Column({ type: 'varchar',length:1 })
  stp_daily:string

  @Column({ type: 'varchar',length:1 })
  stp_fortnightly:string

  @Column({ type: 'varchar',length:1 })
  stp_half_yearly:string

  @Column({ type: 'varchar',length:1 })
  stp_yearly:string

  @Column({ type: 'varchar',length:1 })
  stp_weekly:string

  @Column({ type: 'int' })
  stp_minimum_amount:number
  
  @Column({ type: 'int', })
  stp_min_amount_monthly:number

  @Column({ type: 'int', })
  stp_min_amount_quarterly:number

  @Column({ type: 'int', })
  stp_min_amount_daily:number

  @Column({ type: 'int', })
  stp_min_amount_fortnightly:number

  @Column({ type: 'int', })
  stp_min_amount_half_yearly:number

  @Column({ type: 'int', })
  stp_min_amount_yearly:number

  @Column({ type: 'int', })
  stp_min_amount_weekly:number

  @Column({ type: 'int', })
  stp_multiple_amount:number

  @Column({ type: 'int', })
  stp_maximum_amount:number

  @Column({ type: 'int', })
  stp_minimum_units:number

  @Column({ type: 'int', })
  stp_min_units_monthly:number

  @Column({ type: 'int', })
  stp_min_units_quarterly:number

  @Column({ type: 'int', })
  stp_min_units_daily:number

  @Column({ type: 'int', })
  stp_min_units_fortnightly:number

  @Column({ type: 'int', })
  stp_min_units_half_yearly:number

  @Column({ type: 'int', })
  stp_min_units_yearly:number

  @Column({ type: 'int', })
  stp_min_units_weekly:number

  @Column({ type: 'int', })
  stp_multiple_units:number

  @Column({ type: 'int', })
  stp_maximum_units:number

  
  //stp_starting_dates_monthly
  //stp_starting_dates_quarterly
  //stp_starting_dates_daily
  //stp_starting_dates_fortnightly
  //stp_starting_dates_half_yearly
  //stp_starting_dates_yearly
  //stp_starting_dates_weekly
  //stp_starting_days_weekly

  @Column({ type: 'int', })
  stp_min_installments_monthly:number

  @Column({ type: 'int', })
  stp_min_installments_quarterly:number

  @Column({ type: 'int', })
  stp_min_installments_daily:number

  @Column({ type: 'int', })
  stp_min_installments_fortnightly:number

  @Column({ type: 'int', })
  stp_min_installments_half_yearly:number

  @Column({ type: 'int', })
  stp_min_installments_weekly:number























 

 
}