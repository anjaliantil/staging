import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { TimestampEntity } from './timestamp.entity';

@Entity('colour_code')
export class ColourCode extends TimestampEntity {
  

  @PrimaryColumn({ type: 'bigint' })
  colour_id:number

  @Column({ type: 'varchar', length: 50 })
  colour_name: string;

  @Column({ type: 'varchar', length: 50 })
  risk: string;

 
}