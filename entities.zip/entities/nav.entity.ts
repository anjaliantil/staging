import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { TimestampEntity } from './timestamp.entity';

@Entity('nav')
export class Nav extends TimestampEntity {
  

  @PrimaryColumn({ type: 'int' })
  plan_id:number

  @PrimaryColumn({ type: 'date' })
  nav_date:Date

  @Column({ type: 'numeric', precision:22,scale:6 })
  nav: number;

  @Column({ type: 'numeric', precision:22,scale:6 })
  adjusted_nav: number;

 
}