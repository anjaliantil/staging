import { Entity, Column, PrimaryColumn,  } from 'typeorm';
import { StatsEntity } from './stats.entity';

@Entity('category_average_statvariables')
export class CategoryAverageStatVariables extends StatsEntity {
  

  @Column({ type: 'int' })
  fund_category_id:number

  @Column({ type: 'int' })
  fund_type_id:number

  @Column({ type: 'varchar', length: 50 })
  performance_share_class: string;

  @Column({ type: 'date' })
  stats_variables_date:Date

  @Column({ type: 'int' })
  standard_deviation_count:number

  @Column({ type: 'int' })
  beta_count:number

  @Column({ type: 'int' })
  rsquared_count:number

  @Column({ type: 'int' })
  sharpe_ratio_count:number

  @Column({ type: 'int' })
  alpha_count:number

  @Column({ type: 'int' })
  sortino_ratio_count:number

  @Column({ type: 'int' })
  mean_count:number

  @Column({ type: 'int' })
  information_ratio_count:number


 
}