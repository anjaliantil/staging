import { Entity, Column, PrimaryColumn} from 'typeorm';
import { TimestampEntity } from './timestamp.entity';
import { CommonEntity } from './common.entity';

@Entity('fund_plans')
export class FundPlans extends CommonEntity {
  @Column({ type: 'varchar', length: 150 })
  basic_name: string;

  @Column({ type: 'varchar', length: 100 })
  short_name: string;

  
  @Column({ type: 'varchar', length: 50 })
  plan_name: string;

  
  @Column({ type: 'varchar', length: 255 })
  basic_short_name: string;
 
  
  @Column({ type: 'varchar', length: 255 })
  scheme_name: string;

  
  @Column({ type: 'bigint'})
  amc_id: number;

  @Column({ type: 'bigint'})
  category_id: number;

  @Column({ type: 'varchar',length:50})
  type_id: number;

  @Column({ type: 'numeric',precision:18,scale:2})
  face_value: number;

  @Column({ type: 'bigint'})
  min_initial_investment: number;

  @Column({ type: 'bigint'})
  min_subsequent_investment: number;

  @Column({ type: 'bigint'})
  min_withdrawl_amount: number;

  @Column({ type: 'boolean'})
  sip: boolean;

  @Column({ type: 'bigint'})
  min_subsequent_sip_investment: number;

  @Column({ type: 'text'})
  sip_note: string;

  @Column({ type: 'boolean'})
  swp: number;

  @Column({ type: 'bigint'})
  min_swp_widw: number;

  @Column({ type: 'boolean'})
  stp: number;

  @Column({ type: 'bigint'})
  min_balance: number;

  @Column({ type: 'text'})
  redemption_note: string;

  @Column({ type: 'bigint'})
  equity_max: number;

  @Column({ type: 'bigint'})
  equity_min: number;

  @Column({ type: 'bigint'})
  debt_max: number;

  @Column({ type: 'bigint'})
   debt_min: number;

  @Column({ type: 'bigint'})
  money_mkt_max: number

  @Column({ type: 'bigint'})
  money_mkt_min: number

  @Column({ type: 'date' })
  issue_open: Date;

  @Column({ type: 'date' })
  issue_stated_close: Date;

  @Column({ type: 'date' })
  issue_actual_close: Date;

  @Column({ type: 'date' })
  allotment_date: Date;

  @Column({ type: 'date' })
  late_redemption: Date;

  @Column({ type: 'date' })
  resale_start_date: Date;

  @Column({ type: 'varchar',length:200 })
  transfer_agent: string;

  @Column({ type: 'varchar',length:70 })
  transfer_agent_short_name: string;

  @Column({ type: 'varchar',length:50 })
  transfer_agent_email: string;

  @Column({ type: 'varchar',length:50 })
  amfi_code: string;

  @Column({ type: 'text' })
  objective_text: string;

  @Column({ type: 'text' })
  benchmark: string;

  @Column({ type: 'varchar',length:50 })
  rta_code: string;

  @Column({ type: 'int' })
  colour: number;

  @Column({ type: 'varchar',length:15 })
  isin_code: string;

  @Column({ type: 'boolean' })
  is_dividend: boolean;

  @Column({ type: 'int' })
  auditor_code: number;

  @Column({ type: 'int' })
  custodian_code: number;

  @Column({ type: 'boolean' })
  is_direct_plan: boolean;

  @Column({ type: 'bigint' })
  reg_plan_id: number;

  @Column({ type: 'varchar',length:15 })
  status: string;

  @Column({ type: 'boolean' })
  new_fund: boolean;

  @Column({ type: 'varchar',length:50 })
  dividend_periodicity: string;

  @Column({ type: 'boolean' })
  is_etf_fund: boolean;

  @Column({ type: 'boolean' })
  lock_in: boolean;

  @Column({ type: 'int' })
  lock_in_period_days: number;

  @Column({ type: 'boolean' })
  variant: boolean;

  @Column({ type: 'bigint' })
  variant_fund_id: number;

  @Column({ type: 'boolean' })
  is_rgess_plan: boolean;

  @Column({ type: 'numeric',precision:24,scale:4})
  min_widw_unit: number;

  @Column({ type: 'numeric',precision:24,scale:4})
  min_subsequent_investment_unit: number;

  @Column({ type: 'int' })
  min_investment_multiples: number;

  @Column({ type: 'varchar',length:20 })
  transaction_status: string;

  @Column({ type: 'numeric',precision:24,scale:8})
  stated_annual_expense: number;

  @Column({ type: 'bigint' })
  max_inv_amount: number;

  @Column({ type: 'boolean' })
  is_fof: boolean;
  
  @Column({ type: 'date' })
  last_etf_trade_date: Date;

  @Column({ type: 'boolean' })
  is_index_fund: boolean;

  @Column({ type: 'bigint' })
  min_withdrawal_multiple_amount: number;

  @Column({ type: 'boolean' })
  minor_investments_allowed: boolean;

  @Column({ type: 'bit' })
  is_retirement_fund: string;

  @Column({ type: 'boolean' })
  is_interval_fund: boolean;






  


  


  
}