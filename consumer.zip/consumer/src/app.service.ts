import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  orders:any=[]
 handleOrderPlaced(order:any){
  console.log(`Received a new order-customer:${order.email}`)
  this.orders.push(order)
 }

}
